#define _CRT_SECURE_NO_WARNINGS
#define BOOST_CONFIG_SUPPRESS_OUTDATED_MESSAGE

#include <iostream>
#include <fstream>
#include <vector>
#include <list>
#include <set>
#include <string>
#include <boost/algorithm/string/split.hpp> // for string split operation
#include <boost/algorithm/string/trim.hpp> // for string trim operation
#include <boost/intrusive/list.hpp> // for doubly linked list

using namespace boost::intrusive;

// Away team info for a player
class away_info : public list_base_hook<> {
public:
	away_info() {
		away_team = "";
		minute_of_goal = 0;
		match_id = 0;
	}
	list_member_hook<> member_hook_;

	std::string away_team;
	int minute_of_goal;
	int match_id;
};

// Player node
class player {
public:
	player() {
		player_name = "";
		team_name = "";
	}
	player(const player&) = default;
	player& operator=(const player&) = default;

	std::string player_name;
	std::string team_name;
	boost::intrusive::list<away_info> away; // Away team info for each player (doubly linked list)
};

void print_vec(std::vector<std::string>, std::ofstream&);
void print_main_list(std::list<player*>&);
player* find_player(std::string, std::list<player*>&);
bool compare_list(const player*, const player*);
std::string period_with_max_goals(std::list<player*>&);
std::vector<std::string> max_goal_scored_players(std::list<player*>&);
std::vector<std::string> hat_trick_scored_players(std::list<player*>&);
std::vector<std::string> get_team_list(std::list<player*>&);
std::vector<std::string> get_player_list(std::list<player*>&);
void print_matches_goals(std::list<player*>&, std::vector<std::string>&, std::ofstream&);
void print_matches_asc(std::list<player*>&, std::vector<std::string>&, std::ofstream&);
void print_matches_desc(std::list<player*>&, std::vector<std::string>&, std::ofstream&);
bool compare_set_asc(const int, const int);
bool compare_set_desc(const int, const int);

int main(int argv, char *argc[])
{
	std::ifstream in_file, op_file;
	std::ofstream out_file;
	std::list<player*> main_list; // data from input.txt
	std::vector<std::vector<std::string> > op_vector; // data from operations.txt

	in_file.open(argc[1]);
	op_file.open(argc[2]);
	out_file.open(argc[3]);

	while (in_file) {
		std::string in_data;
		std::vector<std::string> result;

		getline(in_file, in_data); // read in each line from input.txt and
		boost::split(result, in_data, boost::is_any_of(",")); // split with ',' as delimiter

		if (result.size() == 5) {
			// start populating player nodes and correponding away team infos
			player *p = new player();
			boost::algorithm::trim(result[0]);
			p->player_name = result[0];
			boost::algorithm::trim(result[1]);
			p->team_name = result[1];

			away_info *ai = new away_info(); // away team info for a player
			boost::algorithm::trim(result[2]);
			ai->away_team = result[2];
			ai->minute_of_goal = std::stoi(result[3]);
			ai->match_id = std::stoi(result[4]);

			// if the player node is already in the 'main_list',
			// then append the new node 'ai' to the existing player node 'found_p'
			// else add 'ai' to the newly created node 'p'
			player *found_p = find_player(p->player_name, main_list);
			if (found_p) {
				found_p->away.push_back(*ai);
			}
			else {
				p->away.push_back(*ai);
				main_list.push_back(p);
			}
		}
	}
	in_file.close();
	main_list.sort(compare_list); // sort the player nodes according to player name
	// print_main_list(main_list); // just for debugging

	while (op_file) {
		std::string in_data;
		std::vector<std::string> result;

		getline(op_file, in_data);
		if (in_data != "") {
			boost::split(result, in_data, boost::is_any_of(",")); // split the player names from each line of operations.txt file with ',' delimiter
			for (size_t i = 0; i < result.size(); ++i) {
				boost::algorithm::trim(result[i]);
			}
			op_vector.push_back(result); // and insert into 'op_vector'
		}
	}
	op_file.close();

	// print_main_list(main_list);
	out_file << "1)THE MOST SCORED HALF\n";
	out_file << period_with_max_goals(main_list) << std::endl;

	out_file << "2)GOAL SCORER\n";
	print_vec(max_goal_scored_players(main_list), out_file);

	out_file << "3)THE NAMES OF FOOTBALLERS WHO SCORED HAT-TRICK\n";
	print_vec(hat_trick_scored_players(main_list), out_file);

	out_file << "4)LIST OF TEAMS\n";
	print_vec(get_team_list(main_list), out_file);

	out_file << "5)LIST OF FOOTBALLERS\n";
	print_vec(get_player_list(main_list), out_file);

	int indx = 6, i = 0;
	out_file << indx++ << ")MATCHES OF GIVEN FOOTBALLER" << std::endl;
	print_matches_goals(main_list, op_vector[i++], out_file);
	out_file << indx++ << ")ASCENDING ORDER ACCORDING TO MATCH ID" << std::endl;
	print_matches_asc(main_list, op_vector[i++], out_file);
	out_file << indx++ << ")DESCENDING ORDER ACCORDING TO MATCH ID" << std::endl;
	print_matches_desc(main_list, op_vector[i++], out_file);

	return 0;
}

// utility to print a vector of strings to the output.txt file
void print_vec(std::vector<std::string> v, std::ofstream& out_file) {
	for (size_t i = 0; i < v.size(); ++i)
		out_file << v[i] << std::endl;
}

// utility tp print the main_list to the output.txt file
void print_main_list(std::list<player*>& ml) {
	for (std::list<player*>::iterator mit = ml.begin(); mit != ml.end(); ++mit) {
		std::cout << (*mit)->player_name << ":" << (*mit)->team_name << std::endl;
		for (boost::intrusive::list<away_info>::iterator it = (*mit)->away.begin(); it != (*mit)->away.end(); ++it)
			std::cout << "\t" << it->away_team << ":" << it->minute_of_goal << ":" << it->match_id << std::endl;
	}
}

// find if there's already a node present in the main linked list for a given player
player* find_player(std::string p_name, std::list<player*>& ml) {
	for (std::list<player*>::iterator mit = ml.begin(); mit != ml.end(); ++mit)
		if ((*mit)->player_name == p_name)
			return *mit;
	return NULL;
}

// compare function for sorting the list of player nodes, according to their names
bool compare_list(const player* first, const player* second) {
	return first->player_name < second->player_name;
}

// function for finding the period in which maximum goals are scored
std::string period_with_max_goals(std::list<player*>& ml) {
	int num_goals_in_first_half = 0, num_goals_in_second_half = 0;
	for (std::list<player*>::iterator mit = ml.begin(); mit != ml.end(); ++mit) {
		for (boost::intrusive::list<away_info>::iterator it = (*mit)->away.begin(); it != (*mit)->away.end(); ++it) {
			if (it->minute_of_goal <= 45) num_goals_in_first_half++; // for goals scored in first half
			else num_goals_in_second_half++; // for goals scored in second half
		}
	}
	if (num_goals_in_first_half > num_goals_in_second_half) return std::string("first half");
	else return std::string("second half");
}

// function for finding the players who scored maximum goals
std::vector<std::string> max_goal_scored_players(std::list<player*>& ml) {
	std::vector<std::string> p_names(ml.size(), "");
	std::vector<size_t> goals(ml.size(), 0);
	unsigned i = 0;
	// first collect the player names and their corresponding number of goals
	for (std::list<player*>::iterator mit = ml.begin(); mit != ml.end(); ++mit) {
		p_names[i] = (*mit)->player_name;
		goals[i] += (*mit)->away.size();
		i++;
	}

	std::vector<std::string> max_scored_p_names;
	size_t max_goals = 0;
	for (size_t i = 0; i < p_names.size(); ++i) {
		if (goals[i] >= max_goals) {
			if (goals[i] > max_goals) { // for switching between players, according to number of goals
				max_scored_p_names.clear();
			}
			max_scored_p_names.push_back(p_names[i]); // if more than one player has the same maximum goal
			max_goals = goals[i];
		}
	}
	return max_scored_p_names;
}

// function for finding players who scored hat-trick goals
std::vector<std::string> hat_trick_scored_players(std::list<player*>& ml) {
	std::vector<std::string> p_names(ml.size(), "");
	std::vector<std::vector<int> > match_ids(ml.size());
	unsigned i = 0;
	// collect the player names and corresponding list of match ids
	for (std::list<player*>::iterator mit = ml.begin(); mit != ml.end(); ++mit) {
		p_names[i] = (*mit)->player_name;
		for (boost::intrusive::list<away_info>::iterator it = (*mit)->away.begin(); it != (*mit)->away.end(); ++it) {
			match_ids[i].push_back(it->match_id);
		}
		i++;
	}

	std::vector<std::string> hat_trick_scored_p_names; // for storing players who scored hat-trick
	for (size_t i = 0; i < p_names.size(); ++i) {
		if (match_ids[i].size() >= 3) { // narrowing down the search to players who scored >= 3 goals
			std::sort(match_ids[i].begin(), match_ids[i].end()); // sort the match ids
			int id = match_ids[i][0];
			int count = 0;
			for (size_t j = 0; j < match_ids[i].size(); ++j) {
				if (match_ids[i][j] == id) { // if the id is repeated
					count++; // start counting the number of repititions
				}
				else {
					id = match_ids[i][j]; // if there's an id change while looping, then the old id is not associated to hat-trick
					count = 1;
				}
				if (count == 3) {
					// in case of hat-trick
					hat_trick_scored_p_names.push_back(p_names[i]);
					break; // break and start with another player
				}
			}
		}
	}
	return hat_trick_scored_p_names;
}

// function for getting the list of teams
std::vector<std::string> get_team_list(std::list<player*>& ml) {
	std::set<std::string> teams; // 'set' to get a unique list of team names
	for (std::list<player*>::iterator mit = ml.begin(); mit != ml.end(); ++mit) {
		teams.insert((*mit)->team_name);
		for (boost::intrusive::list<away_info>::iterator it = (*mit)->away.begin(); it != (*mit)->away.end(); ++it) {
			teams.insert(it->away_team);
		}
	}
	return std::vector<std::string>(teams.begin(), teams.end());
}

// function for getting the list of players
std::vector<std::string> get_player_list(std::list<player*>& ml) {
	std::set<std::string> p_names;
	for (std::list<player*>::iterator mit = ml.begin(); mit != ml.end(); ++mit)
		p_names.insert((*mit)->player_name);
	return std::vector<std::string>(p_names.begin(), p_names.end());
}

// function for printing the match ids and number of goals associated with given players from operations.txt file
void print_matches_goals(std::list<player*>& ml, std::vector<std::string>& op_vec, std::ofstream& out_file) {
	std::vector<std::string> p_names;
	std::vector<std::vector<std::string> > away_teams;
	std::vector<std::vector<int> > mins;
	std::vector<std::vector<int> > match_ids;
	size_t i = 0;
	for (std::list<player*>::iterator mit = ml.begin(); mit != ml.end(); ++mit) {
		if (std::find(op_vec.begin(), op_vec.end(), (*mit)->player_name) == op_vec.end()) continue; // print data only for given players
		p_names.push_back((*mit)->player_name);
		away_teams.push_back(std::vector<std::string>());
		mins.push_back(std::vector<int>());
		match_ids.push_back(std::vector<int>());
		// collect the data, not printing yet
		for (boost::intrusive::list<away_info>::iterator it = (*mit)->away.begin(); it != (*mit)->away.end(); ++it) {
			away_teams[i].push_back(it->away_team);
			mins[i].push_back(it->minute_of_goal);
			match_ids[i].push_back(it->match_id);
		}
		i++;
	}

	// print the data
	for (i = 0; i < p_names.size(); ++i) {
		out_file << "Matches of " << p_names[i] << "\n";
		for (size_t j = 0; j < away_teams[i].size(); ++j) {
			out_file << "Footballer Name: " << p_names[i] << ",";
			out_file << "Away Team: " << away_teams[i][j] << ",";
			out_file << "Min of Goal: " << mins[i][j] << ",";
			out_file << "Match ID: " << match_ids[i][j] << "\n";
		}
	}
}

// function for printing the data for given players in ascending order of match ids
void print_matches_asc(std::list<player*>& ml, std::vector<std::string>& op_vec, std::ofstream& out_file) {
	std::vector<std::set<int> > match_ids;
	size_t i = 0;
	for (std::list<player*>::iterator mit = ml.begin(); mit != ml.end(); ++mit) {
		if (std::find(op_vec.begin(), op_vec.end(), (*mit)->player_name) == op_vec.end()) continue;
		match_ids.push_back(std::set<int>());
		for (boost::intrusive::list<away_info>::iterator it = (*mit)->away.begin(); it != (*mit)->away.end(); ++it) {
			match_ids[i].insert(it->match_id);
		}
		std::vector<int> match_ids_vec(match_ids[i].begin(), match_ids[i].end());
		std::sort(match_ids_vec.begin(), match_ids_vec.end(), compare_set_asc); // sort in ascending order
		for (std::vector<int>::iterator it = match_ids_vec.begin(); it != match_ids_vec.end(); ++it) {
			out_file << "footballer Name: " << (*mit)->player_name << ",Match ID:" << *it << std::endl;
		}
		i++;
	}
}

// function for printing the data for given players in descending order of match ids
void print_matches_desc(std::list<player*>& ml, std::vector<std::string>& op_vec, std::ofstream& out_file) {
	std::vector<std::set<int> > match_ids;
	size_t i = 0;
	for (std::list<player*>::iterator mit = ml.begin(); mit != ml.end(); ++mit) {
		if (std::find(op_vec.begin(), op_vec.end(), (*mit)->player_name) == op_vec.end()) continue;
		match_ids.push_back(std::set<int>());
		for (boost::intrusive::list<away_info>::iterator it = (*mit)->away.begin(); it != (*mit)->away.end(); ++it) {
			match_ids[i].insert(it->match_id);
		}
		std::vector<int> match_ids_vec(match_ids[i].begin(), match_ids[i].end());
		std::sort(match_ids_vec.begin(), match_ids_vec.end(), compare_set_desc); // sort in descending order
		for (std::vector<int>::iterator it = match_ids_vec.begin(); it != match_ids_vec.end(); ++it) {
			out_file << "footballer Name: " << (*mit)->player_name << ", Match ID: " << *it << std::endl;
		}
		i++;
	}
}

// compare function for sorting the set in ascending order
bool compare_set_asc(const int first, const int second) {
	return first < second;
}

// compare function for sorting the set in descending order
bool compare_set_desc(const int first, const int second) {
	return first > second;
}
